## ----eval = FALSE-------------------------------------------------------------
#  install.packages('box', repos = 'https://klmr.r-universe.dev')

## ----eval = FALSE-------------------------------------------------------------
#  pak::pak('klmr/box@build')

